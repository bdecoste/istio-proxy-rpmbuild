#pragma once

#define LIGHTSTEP_VERSION "0.6.1"
