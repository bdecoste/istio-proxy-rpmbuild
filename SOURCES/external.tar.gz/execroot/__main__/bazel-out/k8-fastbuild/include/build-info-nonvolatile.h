#define BUILD_EMBED_LABEL ""
#define BUILD_HOST "ose3x-master.example.com"
#define BUILD_USER "root"
