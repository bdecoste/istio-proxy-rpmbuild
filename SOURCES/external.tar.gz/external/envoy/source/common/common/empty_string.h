#pragma once

#include <string>

namespace Envoy {
static const std::string EMPTY_STRING = "";
} // namespace Envoy
