# Simple echo server for proxy testing.

golang implementation of echo server.
